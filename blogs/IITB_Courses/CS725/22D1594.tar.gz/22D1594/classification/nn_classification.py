import sys
import os
import numpy as np
import pandas as pd

# The seed will be fixed to 42 for this assignment.
np.random.seed(42)

NUM_FEATS = 90


def relu(Z):
    return np.maximum(0, Z)


def relu_prime(Z):
    return np.where(Z < 0, 0, 1)


# Here we define the dict labels
int_to_label = {0: "Very Old", 1: "Old", 2: "New", 3: "Recent"}
label_to_int = {"Very Old": 0, "Old": 1, "New": 2, "Recent": 3}


def softmax(x, axis=-1):
    """returns result of the softmax activation function on input z."""
    kw = dict(axis=axis, keepdims=True)

    # make every value 0 or below, as exp(0) won't overflow
    xrel = x - x.max(**kw)

    # if you wanted better handling of small exponents, you could do something like this
    # to try and make the values as large as possible without overflowing, The 0.9
    # is a fudge factor to try and ignore rounding errors
    #
    #     xrel += np.log(np.finfo(float).max / x.shape[axis]) * 0.9

    exp_xrel = np.exp(xrel)
    return exp_xrel / exp_xrel.sum(**kw)


class Net(object):
    """
    """

    def __init__(self, num_layers, num_units, output_layer_neuron):
        """
        Initialize the neural network.
        Create weights and biases.

        Here, we have provided an example structure for the weights and biases.
        It is a list of weight and bias matrices, in which, the
        dimensions of weights and biases are (assuming 1 input layer, 2 hidden layers, and 1 output layer):
        weights: [(NUM_FEATS, num_units), (num_units, num_units), (num_units, num_units), (num_units, 1)]
        biases: [(num_units, 1), (num_units, 1), (num_units, 1), (num_units, 1)]

        Please note that this is just an example.
        You are free to modify or entirely ignore this initialization as per your need.
        Also, you can add more state-tracking variables that might be useful to compute
        the gradients efficiently.


        Parameters
        ----------
            num_layers : Number of HIDDEN layers.
            num_units : Number of units in each Hidden layer.
        """
        self.num_layers = num_layers
        self.num_units = num_units
        self.output_layer_neuron = output_layer_neuron

        self.biases = []
        self.weights = []

        for i in range(num_layers):

            if i == 0:
                # Input layer
                self.weights.append(np.random.uniform(-1, 1, size=(NUM_FEATS, self.num_units)))
            else:
                # Hidden layer
                self.weights.append(np.random.uniform(-1, 1, size=(self.num_units, self.num_units)))

            self.biases.append(np.random.uniform(-1, 1, size=(1, self.num_units)))

        # Output layer
        self.biases.append(np.random.uniform(-1, 1, size=(1, self.output_layer_neuron)))
        self.weights.append(np.random.uniform(-1, 1, size=(self.num_units, self.output_layer_neuron)))

        self.nn = {}
        self.op = {}
        self.del_W = {}
        self.del_b = {}

    def __call__(self, X):
        """
        Forward propagate the input X through the network,
        and return the output.

        Note that for a classification task, the output layer should
        be a softmax layer. So perform the computations accordingly

        Parameters
        ----------
            X : Input to the network, numpy array of shape m x d
        Returns
        ----------
            y : Output of the network, numpy array of shape m x 1
        """

        self.nn[0] = np.array(X.dot(self.weights[0]) + self.biases[0])
        self.op[0] = np.array(relu(self.nn[0]))
        for i in range(1, self.num_layers + 1):
            self.nn[i] = np.array(self.op[i - 1].dot(self.weights[i]) + self.biases[i])
            if i != self.num_layers:
                self.op[i] = np.array(relu(self.nn[i]))
            else:
                self.op[i] = np.array(softmax(self.nn[i]))
        return self.op[self.num_layers]

    def backward(self, X, y, lamda):
        """
        Compute and return gradients loss with respect to weights and biases.
        (dL/dW and dL/db)

        Parameters
        ----------
            X : Input to the network, numpy array of shape m x d
            y : Output of the network, numpy array of shape m x 1
            lamda : Regularization parameter.

        Returns
        ----------
            del_W : derivative of loss w.r.t. all weight values (a list of matrices).
            del_b : derivative of loss w.r.t. all bias values (a list of vectors).

        Hint: You need to do a forward pass before performing backward pass.
        """
        # Forward pass
        self.__call__(X)

        # Backward Pass
        m = X.shape[0]
        i = self.num_layers
        dLdo = (self.op[i] - y) / m

        dLdW = self.op[i - 1].T.dot(dLdo)
        dLdb = np.sum(dLdo, axis=0, keepdims=True)
        self.del_W[i] = dLdW + lamda * self.weights[i]
        self.del_b[i] = dLdb
        dLdV_dVdU = (dLdo.dot(self.weights[i].T))

        for j in range(self.num_layers - 1, -1, -1):
            dLdn = np.array(dLdV_dVdU, copy=True)
            dLdn = dLdn * relu_prime(self.op[j])
            if j == 0:
                dLdW = X.T.dot(dLdn)
            else:
                dLdW = self.op[j - 1].T.dot(dLdn)
            dLdb = np.sum(dLdn, axis=0, keepdims=True)
            self.del_W[j] = dLdW + lamda * self.weights[j]
            self.del_b[j] = dLdb
            dLdV_dVdU = dLdn.dot(self.weights[j].T)

        return self.del_W, self.del_b


class Optimizer(object):
    """
    """

    def __init__(self, learning_rate, num_layers, num_units, beta, gamma):
        """
        Create a Gradient Descent based optimizer with given
        learning rate.

        Other parameters can also be passed to create different types of
        optimizers.

        Hint: You can use the class members to track various states of the
        optimizer.
        """
        self.learning_rate = learning_rate
        self.num_layers = num_layers
        self.num_units = num_units
        self.beta = beta
        self.gamma = gamma
        self.velocity_weight = []
        self.velocity_bias = []
        self.s_weight = []
        self.s_bias = []
        self.t = 1

        for i in range(num_layers):

            if i == 0:
                # Input layer
                self.velocity_weight.append(np.zeros((NUM_FEATS, self.num_units)))
                self.s_weight.append(np.zeros((NUM_FEATS, self.num_units)))
            else:
                # Hidden layer
                self.velocity_weight.append(np.zeros((self.num_units, self.num_units)))
                self.s_weight.append(np.zeros((self.num_units, self.num_units)))
            self.velocity_bias.append(np.zeros((1, self.num_units)))
            self.s_bias.append(np.zeros((1, self.num_units)))

        # Output layer
        self.velocity_bias.append(np.zeros((1, 1)))
        self.velocity_weight.append(np.zeros((self.num_units, 1)))
        self.s_bias.append(np.zeros((1, 1)))
        self.s_weight.append(np.zeros((self.num_units, 1)))

    def step(self, weights, biases, delta_weights, delta_biases):
        """
        Parameters
        ----------
            weights: Current weights of the network.
            biases: Current biases of the network.
            delta_weights: Gradients of weights with respect to loss.
            delta_biases: Gradients of biases with respect to loss.
        """
        weight = []
        bias = []
        for i in range(len(weights)):
            self.velocity_weight[i] = self.beta * (self.velocity_weight[i]) + (1 - self.beta) * delta_weights[i]
            self.s_weight[i] = (self.gamma * (self.s_weight[i])) + (
                    (1 - self.gamma) * delta_weights[i] * delta_weights[i])
            self.velocity_weight[i] /= (1 - (self.beta ** self.t))
            self.s_weight[i] /= (1 - (self.gamma ** self.t))
            # weight.append(weights[i] - self.learning_rate * self.velocity_weight[i])
            adap_lr_weight = self.learning_rate / (np.sqrt(self.s_weight[i]) + 1e-8)
            adam_lr_weight = adap_lr_weight * self.velocity_weight[i]
            weight.append(weights[i] - adam_lr_weight)
            self.velocity_bias[i] = self.beta * (self.velocity_bias[i]) + (1 - self.beta) * delta_biases[i]
            self.s_bias[i] = (self.gamma * (self.s_bias[i])) + ((1 - self.gamma) * delta_biases[i] * delta_biases[i])
            self.velocity_bias[i] /= (1 - (self.beta ** self.t))
            self.s_bias[i] /= (1 - (self.gamma ** self.t))
            # bias.append(biases[i] - self.learning_rate * self.velocity_bias[i])
            adap_lr_bias = self.learning_rate / (np.sqrt(self.s_bias[i]) + 1e-8)
            adam_lr_bias = adap_lr_bias * self.velocity_bias[i]
            bias.append(biases[i] - adam_lr_bias)
        self.t += 1
        return weight, bias


def loss_mse(y, y_hat):
    """
    Compute Mean Squared Error (MSE) loss betwee ground-truth and predicted values.

    Parameters
    ----------
        y : targets, numpy array of shape m x 1
        y_hat : predictions, numpy array of shape m x 1

    Returns
    ----------
        MSE loss between y and y_hat.
    """
    mse_loss = np.mean(np.square(y - y_hat))
    return mse_loss


def loss_regularization(weights, biases):
    """
    Compute l2 regularization loss.

    Parameters
    ----------
        weights and biases of the network.

    Returns
    ----------
        l2 regularization loss
    """
    reg_loss = 0
    for w, b in zip(weights, biases):
        reg_loss += (np.sum(np.square(w)) + np.sum(np.square(b)))
    return reg_loss


def loss_fn(y, y_hat, weights, biases, lamda):
    """
    Compute loss =  loss_mse(..) + lamda * loss_regularization(..)

    Parameters
    ----------
        y : targets, numpy array of shape m x 1
        y_hat : predictions, numpy array of shape m x 1
        weights: weights of the network
        biases: biases of the network
        lamda: Regularization parameter

    Returns
    ----------
        l2 regularization loss
    """
    loss = loss_mse(y, y_hat) + lamda * loss_regularization(weights, biases)
    return loss


def loss_fn_ce(y, y_hat, weights, biases, lamda):
    """
    Compute loss =  loss_mse(..) + lamda * loss_regularization(..)

    Parameters
    ----------
        y : targets, numpy array of shape m x 1
        y_hat : predictions, numpy array of shape m x 1
        weights: weights of the network
        biases: biases of the network
        lamda: Regularization parameter

    Returns
    ----------
        l2 regularization loss
    """
    loss = cross_entropy_loss(y, y_hat) + lamda / len(y) * loss_regularization(weights, biases)
    return loss


def rmse(y, y_hat):
    """
    Compute Root Mean Squared Error (RMSE) loss between ground-truth and predicted values.

    Parameters
    ----------
        y : targets, numpy array of shape m x 1
        y_hat : predictions, numpy array of shape m x 1

    Returns
    ----------
        RMSE between y and y_hat.
    """
    rmse_loss = np.sqrt(np.mean(np.square(y - y_hat)))
    return rmse_loss


def cross_entropy_loss(y, y_hat):
    """
    Compute cross entropy loss

    Parameters
    ----------
        y : targets, numpy array of shape m x 1
        y_hat : predictions, numpy array of shape m x 1

    Returns
    ----------
        cross entropy loss
    """
    epsilon = 1e-8
    predicted = np.clip(y_hat, epsilon, 1. - epsilon)
    N = predicted.shape[0]
    innerProd = np.sum(-1 * np.multiply(y, np.log(y_hat)), axis=1, keepdims=True)
    z = np.sum(innerProd)
    ce = 1 / (len(y)) * z
    return ce


def train(
        net, optimizer, lamda, batch_size, max_epochs,
        train_input, train_target,
        dev_input, dev_target
):
    """
    In this function, you will perform following steps:
        1. Run gradient descent algorithm for `max_epochs` epochs.
        2. For each batch of the training data
            1.1 Compute gradients
            1.2 Update weights and biases using step() of optimizer.
        3. Compute RMSE on dev data after running `max_epochs` epochs.

    Here we have added the code to loop over batches and perform backward pass
    for each batch in the loop.
    For this code also, you are free to heavily modify it.
    """

    m = train_input.shape[0]
    epoch_loss_old = 0.0
    for e in range(max_epochs):
        epoch_loss_new = 0.0

        for i in range(0, m, batch_size):
            batch_input = train_input[i:i + batch_size]
            batch_target = train_target[i:i + batch_size]

            # Compute gradients of loss w.r.t. weights and biases
            dW, db = net.backward(batch_input, batch_target, lamda)

            # Get updated weights based on current weights and gradients
            weights_updated, biases_updated = optimizer.step(net.weights, net.biases, dW, db)

            # Update model's weights and biases
            net.weights = weights_updated
            net.biases = biases_updated

            # Compute loss for the batch
            prediction = net(batch_input)
            batch_loss = loss_fn_ce(batch_target, prediction, net.weights, net.biases, lamda)
            epoch_loss_new += batch_loss

        dev_epoch_loss = evaluate_dev_loss(net, dev_input, dev_target, batch_size, lamda)
        train_accuracy = accuracy(net, train_input, train_target, batch_size)
        dev_accuracy = accuracy(net, dev_input, dev_target, batch_size)
        # print(e, i, rmse(batch_target, pred), batch_loss)
        print(e, epoch_loss_new / int(m / batch_size), dev_epoch_loss, train_accuracy, dev_accuracy)

        # print(e, epoch_loss_new)

        # Early stopping
        if round(epoch_loss_new, 8) == round(epoch_loss_old, 8):
            break
        else:
            epoch_loss_old = epoch_loss_new
        # Write any early stopping conditions required (only for Part 2)
        # Hint: You can also compute dev_rmse here and use it in the early
        #       stopping condition.

    # After running `max_epochs` (for Part 1) epochs OR early stopping (for Part 2), compute the RMSE on dev data.

    # print('Dev Predictions:', dev_input)


def get_test_data_predictions(net, inputs):
    """
    Perform forward pass on test data and get the final predictions that can
    be submitted on Kaggle.
    Write the final predictions to the part2.csv file.

    Parameters
    ----------
        net : trained neural network
        inputs : test input, numpy array of shape m x d

    Returns
    ----------
        predictions (optional): Predictions obtained from forward pass
                                on test data, numpy array of shape m x 1
    """
    pred = net(inputs)
    y_hat = net(inputs)

    labels = {"Very Old": 0, "Old": 1, "New": 2, "Recent": 3}
    id_labels = {0: "Very Old", 1: "Old", 2: "New", 3: "Recent"}

    index = []
    for i in range(len(y_hat)):
        index.append(i + 1)

    datarows = []
    for i in range(len(y_hat)):
        row = []
        row.append(index[i])
        row.append(id_labels[np.argmax(y_hat[i])])
        datarows.append(row)

    final_csv = pd.DataFrame(datarows).to_csv("22D1594.csv", header=['Id', 'Predictions'], index=False)

    return pred


def read_data(nc=90):
    """
    Read the train, dev, and test datasets
    """
    train_data = pd.read_csv("classification/data/train.csv")
    dev_data = pd.read_csv("classification/data/dev.csv")
    test_data = pd.read_csv("classification/data/test.csv")

    train_target = train_data['1']
    train_data.drop('1', axis='columns', inplace=True)
    mean_value = train_data.mean(axis=0)
    std_value = train_data.std(axis=0)
    train_data = (train_data - mean_value) / std_value

    dev_target = dev_data['1']
    dev_data.drop('1', axis='columns', inplace=True)
    dev_data = (dev_data - mean_value) / std_value

    test_data = (test_data - mean_value) / std_value

    train_input = train_data.to_numpy()
    dev_input = dev_data.to_numpy()
    test_input = test_data.to_numpy()
    train_target = train_target.to_numpy().reshape((len(train_target), 1))
    dev_target = dev_target.to_numpy().reshape((len(dev_target), 1))

    # print(train_target)

    train_target = [label_to_int[it[0]] for it in train_target]
    dev_target = [label_to_int[it[0]] for it in dev_target]

    train_target = np.eye(4)[train_target]
    dev_target = np.eye(4)[dev_target]
    # print("train target = ",train_target.shape)
    # print("dev target = ",train_target)

    return train_input, train_target, dev_input, dev_target, test_input


def standard_scaler(data, params):
    columns = data.columns

    for column in columns:
        if column not in params:
            mean = data[column].mean()
            std = data[column].std()
            params[column] = {}
            params[column]["mean"] = mean
            params[column]["std"] = std

        data[column] -= params[column]["mean"]
        data[column] /= params[column]["std"]

    return data


def accuracy(net, data_input, data_target, batch_size):
    m = len(data_input)
    outputs = []

    for i in range(0, m, batch_size):
        batch_input = data_input[i:i + batch_size]
        batch_target = data_target[i:i + batch_size]
        prediction = net(batch_input)
        outputs += [list(out) for out in prediction]

    correct = 0
    for i in range(len(outputs)):
        if np.argmax(outputs[i]) == np.argmax(data_target[i]):
            correct += 1

    return 100 * correct / len(data_target)


def evaluate_dev_loss(net, dev_input, dev_target, batch_size, lamda):
    m = len(dev_input)

    epoch_loss = 0
    for i in range(0, m, batch_size):
        batch_input = dev_input[i:i + batch_size]
        batch_target = dev_target[i:i + batch_size]
        pred = net(batch_input)

        batch_loss = loss_fn(batch_target, pred,
                             net.weights, net.biases, lamda)
        epoch_loss += batch_loss

    return epoch_loss / int(m / batch_size)


def main():
    max_epochs = 400
    batch_size = 64
    learning_rate = 1e-3
    num_layers = 1
    num_units = 64
    lamda = 0.01  # Regularization Parameter
    beta = 0.8
    gamma = 0.9
    nc = 90

    hp_name = ['Number_of_hidden_layers', 'Number_of_neurons_in_hidden_layer', 'Batch_size', 'Learning_rate',
               'Adam_parameter_beta', 'Adam_parameter_gamma', 'Regularization_parameter_lambda', 'Maximum_epochs',
               'Number_of_principal_components']
    hp_val = [num_layers, num_units, batch_size, learning_rate, beta, gamma, lamda, max_epochs, nc]

    params_dict = {
        'Name': hp_name,
        'Value': hp_val
    }

    params_df = pd.DataFrame(params_dict)
    params_df.to_csv("params.csv", index=False)

    train_input, train_target, dev_input, dev_target, test_input = read_data(nc)
    net = Net(num_layers, num_units, output_layer_neuron=4)
    optimizer = Optimizer(learning_rate, num_layers, num_units, beta, gamma)
    train(
        net, optimizer, lamda, batch_size, max_epochs,
        train_input, train_target,
        dev_input, dev_target
    )

    get_test_data_predictions(net, test_input)


if __name__ == '__main__':
    main()
