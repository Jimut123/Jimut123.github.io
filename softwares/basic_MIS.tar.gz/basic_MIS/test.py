from AppOperations import AppOperations as ao
from AppOperations import Rec
from MISman import MIS_calculations
from load_data import cleanData
#ao.update_Sl(3,'2018-07-30T20:15:54')
#ao.reset_slno()
#k = Rec.timestmp()
#print("Type of k : ",type(k))
#print(Rec.timestmp())
#val = "T-93"
#MIS_calculations.separate_data("recpt_fees",7800)

cleanData.cleanItem("l' a te '")